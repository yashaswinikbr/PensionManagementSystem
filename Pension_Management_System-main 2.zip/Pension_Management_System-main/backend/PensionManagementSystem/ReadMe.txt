Pod 2 MFPE
Pension Management System

Developed by:
Himanshu shivhare
Khushagra sahu
Saloni Mehra
Deepansh
Sumit 
--------------------------------------------------------------------------------------------------
Web Portal Access point: http://localhost:9096/

Database Access points:
Bank log table: http://localhost:9092/h2-console/
User Credentials Table : http://localhost:9095/h2-console/

Database credentials:
Username: sa
Password:

Swagger access points:
Webportal: http://localhost:9096/swagger-ui.html
ProcessPension Microservice: http://localhost:9090/swagger-ui.html
PensionDisbursement Microservice: http://localhost:9091/swagger-ui.html
Pensioner Detail Microservice: http://localhost:9092/swagger-ui.html
Authorization Microservice: http://localhost:9095/swagger-ui.html

--------------------------------------------------------------------------------------------------

Example for valid details:

Login Credentials:
Username : admin
Password : admin

Pensioner Detail Form:
Name: Page Glasper
DOB : 27-05-1970
PAN Number : A123456789
Aadhaar Number : 1234567891011120
Pension Type : Family Pension

Process Pension Form:
Aadhaar Number : 1234567891011120
Pension Amount : 6069.98
Bank Service Charge : 550.0
